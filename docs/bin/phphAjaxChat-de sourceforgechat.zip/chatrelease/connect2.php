<?
$server = 'localhost';
$username = 'root';
$password = 'i81uo22';
$database_name = 'khansen';
$chatname='Hansen Chat';
$connection=mysql_connect($server, $username, $password);
mysql_select_db($database_name,$connection);
?>

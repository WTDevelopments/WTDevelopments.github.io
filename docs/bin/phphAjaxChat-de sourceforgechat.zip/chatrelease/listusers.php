<?php
include('loggedin.php');
print listofchatters();
?>

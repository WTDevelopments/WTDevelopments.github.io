<?php
include "phpToAjaxClass/phpToAjaxClass.php";

$x = new phpToAjaxClass("cont");
$x->setDebug();

echo '<div id="menu">';
$x->link("link1 ","prueba1.htm");  

$x->link("link2 ","prueba2.htm");
$x->link("link3 ","prueba3.htm");     
echo '</div>';        
    


//formulario
//  inputs 

$x->Form("prueba_GET_POST.php","t=file:p:nombre;telefono;direccion","enviar;cancelar");

$x->metod='POST';
//$x->Form("prueba_GET_POST.php","nombre1;telefono1;direccion1","enviar;cancelar1");   
$x->Form("prueba_GET_POST.php","t=fileShowImage:img:Image","enviar;cancelar1");                       
 

$x->printTargetDiv("div de Ajax");      

// document.write("<img href='"+url+"'>");
?>    
    



------V1 of phpToajax---------------

To create html with embeded Ajax.


Developed by:
Mauricio P. West
Junin Buenos Aires
email:mauriciopw@hotmail.com
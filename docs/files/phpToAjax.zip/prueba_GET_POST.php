<?php
echo '<pre>';
if(isset($_GET)){print_r($_GET);}
if(isset($_POST)){print_r($_POST);}
echo '</pre>';
?>
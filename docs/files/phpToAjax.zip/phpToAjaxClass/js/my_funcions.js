var nsx,nsy,nstemp;

var ie=document.all;
var ns=document.layers;
var ns6=document.getElementById&&!document.all;

function loadImage(inputName,imageName,divName,widthImage,e){
if (ie||ns6){
		objeto1=document.getElementById? document.getElementById(inputName) : document.all.evalue(inputName);
		objeto2=document.getElementById? document.getElementById(imageName) : document.all.evalue(imageName);
		objeto3=document.getElementById? document.getElementById(divName) : document.all.evalue(divName);
		urlImage=objeto1.value;
		urlImage=strReplace(urlImage,"file:///","http://localhost/");
		urlImage=strReplace(urlImage,"\\",'/');
		urlImage=strReplace(urlImage,"D:","");
 	    urlImage=strReplace(urlImage,"C:","");
	    urlImage=strReplace(urlImage,"/www","");
    	objeto2.src=urlImage;
		objeto2.width = widthImage;

	}					     	
}

function showImage(divName,imageName,widthImage,e){
	if (ie||ns6){
		objeto3=document.getElementById? document.getElementById(divName) : document.all.evalue(divName);		
	    objeto3.style.visibility="visible";
	}
}

function hideImage(divName,e){
	if (ie||ns6){
		objeto3=document.getElementById? document.getElementById(divName) : document.all.evalue(divName);
		objeto3.style.visibility="hidden";
	}
}


function strReplace(cadena,buscar,reemplazaPor){

   var  ss,i,car,cadReturn,secc,strSize,strSizeBuscar;                //Declare variables.
   strSize=cadena.length;
   strSizeBuscar=buscar.length;
   i=0;
   cadReturn='';
   while ( i < strSize) {

   secc=cadena.substr(i,strSizeBuscar);  
   car=cadena.substr(i,1);  
	   if (secc==buscar){
	     i+=(strSizeBuscar-1);
		 cadReturn += reemplazaPor;
	   }else{
	    cadReturn += car;
	   }
	   i++;
   }
   
  
   return(cadReturn);               // Returns "Spain".
}

<?php
define(NL,"\n");
define('URL_LOCAL','file:///D:/www/');
define('URL_DOMINIO','http://localhost/');

class phpToAjaxClass {
      
    public $targetDiv,$defaultText;
    public $formName,$formCounter,$metod;
    public $inputsOfArray,$error,$debug;
    public $isFileImg,$previewImage,$url_local,$ul_dominio;
    //private $header, $body, $elements, $footer;

    function phpToAjaxClass($text) {  
        $this->targetDiv=$text;    
        $this->formCounter=1;   
        $this->metod='GET';
        $this->debug=0;
        $this->widthPreviewImage=200;
        $this->inputsOfArray=Array();
        //$this->form="form".strval($this->formCounter);
        define (RUTA,'phpToAjaxClass/');
      
        
        echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'.NL;
        echo '<link href="'.RUTA.'css/style.css" rel="stylesheet" type="text/css">'.NL; 
        echo '<script type="text/javascript" src="'.RUTA.'ajax/codigo.js"></script>'.NL;   
        echo '<script type="text/javascript" src="'.RUTA.'ajax/libreriaAjax.js"></script>'.NL;
        echo '<script type="text/JavaScript" src="'.RUTA.'js/my_funcions.js"></script>'.NL;                                   
   
            
    }           
                                                         
    function setTargetDiv($text){
        $this->targetDiv=$text;    
    }  
    
    function setFormName($text){
        $this->formName=$text;    
    }   
    
    function setFormMetod($text){
        if(strtoupper($text)=='POST'){
            $this->metod=$text;
        }else{
            $this->errorText= "Error en el metodo enviado al formulario".NL;
           if($this->debug){$this->printErrors($errorText);}   
        }    
    }   
    function setDebug(){
        $this->debug=1;    
        }
    function setPreviewImage($value){
        $this->previewImage=$value;    
        }        
    
    function link($text,$url){  
        echo "<a href=\"";
        echo "javascript:llamarasincrono('";
        echo $url;
        echo "', '";
        echo $this->targetDiv;
        echo "');\" class=\"ajaxLink\" >";
        echo $text;
        echo "</a>".NL;         
    }
    
   function printTargetDiv($text){
   echo '<div id='.$this->targetDiv.'>'.NL;
   echo $text.NL;      
   echo '</div>'.NL;           
   }
   
   
   function printErrors($text){
   echo '<span class="debug">'; 
   echo $text;   
   echo '</span>';
   }   
    
   function formToAjaxGet($toFile,$toLayer,$nombreComponentsForm){ 
        $titulo='';
        $inputName='';
        $nombreComponentsForm=explode(";",$nombreComponentsForm);

        $cadForm='method="GET" ';
        $cadForm.="onsubmit=\"FAjax('".$toFile."?";     
        foreach ($nombreComponentsForm as $parametro){
            $inputName_Title=explode(":",$parametro);
            if (count($inputName_Title)>1){
                $inputName=$parametro;  
            }else{
                $inputName=$inputName_Title[0];
            }
            $cadForm.=$inputName."='+document.getElementById('".$inputName."').value+'&amp;";
            }
        $cadForm=substr($cadForm,0,strlen($cadForm)-7);    
        $cadForm.=",'".$toLayer."','','GET'); return false\"".NL;

        echo $cadForm;
        }

   function formToAjaxPost($toFile,$toLayer,$nombreComponentsForm){ 
        $titulo='';
        $inputName='';
        $nombreComponentsForm=explode(";",$nombreComponentsForm);

        $cadForm='method="POST" ';
        $cadForm.="onsubmit=\"FAjax('".$toFile."','".$toLayer."','";     
        foreach ($nombreComponentsForm as $parametro){
            $inputName_Title=explode(":",$parametro);
            if (count($inputName_Title)>1){
                $inputName=$parametro;  
            }else{
                $inputName=$inputName_Title[0];
            }
            
            
        
            $cadForm.=$inputName."='+document.getElementById('".$inputName."').value+'&amp;";
            }
        $cadForm=substr($cadForm,0,strlen($cadForm)-7);    

        $cadForm.=",'POST'); return false\"".NL;

        echo $cadForm;
        }


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FORM
// va por post o GET segun el parametro que se asigna con: setFormMetod.
// $toFile = php que llama el form.
// $nombreComponentsForm=nombre tipo y titulo de todos los imput que contiene el form.
	// --------------
	// tipos y titulos
//    ;=separacion de inputs  :=separacion de parametros ,=separacion de parametros de parametro.
//    t= (indica el tipo de componente de form que es, puede pasarse este parametro o no) ej: t=file
//       tipos existentes:
//       t=file  Tipo archivo aparece el input con boton examinar
//			Ej: t=file:t=hidden:op:text

//		 t=text (default si no se pasa ningun t=, primer parametro name y el segundo el titulo visible)
//			 Ej: text:texto o t=text:text:texto
//			 
//		 t=hidden (el primer parametro siguiente es el name y el que le sigue el value)
//			 Ej: t=hidden:op:text
//
//		 t=fimage (primer parametro siguiente name y el segundo el titulo visible, y muestra la imagen)
//			 Ej: t=fimage:op:text
//
//   Ejemplo de linea completa de un form
//          t=file:img:Src Img ; alt:Alternativo ; t=hidden:op:text
// 
// $nombre de botones que contiene el form.
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function form($toFile,$nombreComponentsForm,$nombreBotones){
        $inputName='';
        $titulo='';
        $error=0;  
        $posDatos=0;
        $onchangeEvent='';
        $errorText='';
        $type='';     
        $this->isFileImg=0;
        if (isset($this->formName)){
            $formName=$this->$formName;
            $this->formName=NULL;
        }else{
			$formName="f_".strval($this->formCounter);  
			$this->formCounter++; 
		}
                        
        $metod=$this->metod;           
        $toLayer=$this->targetDiv;
        
        
        $aux=Array();    
          

        $nombreComponentsForm=$this->stringParserInputs($nombreComponentsForm);  
        $nombreBotones=explode(";",$nombreBotones);
        
        $aux=$this->returnStringNamesInputs($nombreComponentsForm);  
        echo '<div>'.NL; 
        echo '<form name="'.$formName.'" ';
        $metod=strtoupper($metod);
        if ($metod=='GET'){
        $this->formToAjaxGet($toFile,$toLayer,$aux);
        }else{
        $this->formToAjaxPost($toFile,$toLayer,$aux);
        }    
        echo ' action="#">'.NL; 

        foreach ($nombreComponentsForm as $parametro){
            $inputName=$parametro['name'];  
            $titulo=$parametro['title'];
            
        //foreach ($this->inputsOfArray as $element){
        //echo  '<h2>--'.in_array($inputName,$this->inputsOfArray).'</h2>';
        
             if (in_array($inputName,$this->inputsOfArray)){  
                //if  ($element==$inputName){
                    $errorText= 'Los nombres de los inputs deben ser unicos <BR>'.NL;                   
                    $errorText.= 'Cambie "'.$inputName.'" por otro <BR>'.NL;
                    if($this->debug){$this->printErrors($errorText);}     
                    $error=1;               
                    }
                    
                //}
                
            if ($parametro['type']!='hidden'){
            echo '<label class="l_'.$inputName.'">'.$titulo;
            }
          
            if (isset($parametro['t_cols'])){
                $colsTextfield=' cols= "'.$parametro['t_cols'].'" ';
            }else{
                $colsTextfield='';
            }
            
            if (isset($parametro['t_rows'])){
                $rowsTextfield=' rows= "'.$parametro['t_rows'].'" ';
            }else{
                $rowsTextield='';
            }
            switch ($parametro['type']){
                case 'textfield':{
                    echo '<textarea class="i_'.$inputName.'" id="'.$inputName.'" type="'.$parametro['type'].'"'.$colsTextfield.$rowsTextfield.' ></textarea>';  
                    break;
                }
                case 'hidden':{
                   echo '<input class="i_'.$inputName.'" id="'.$inputName.'" value= "'.$titulo.'" type="'.$parametro['type'].'" >';  
                   echo '</label>';
                   echo "<br />".NL; 
                   break;
                }
                case 'fimage':{
                     
                   $onchange="onchange=\"loadImage('".$inputName."','image_".$inputName."','div_".$inputName."',100,event)\"";
				   $onmouseover="onmouseover=\"showImage('div_".$inputName."',event)\"";
				   $onmouseout="onmouseout=\"hideImage('div_".$inputName."',event)\"";

                   $paramsOn=$onchange.' '.$onmouseover.' '.$onmouseout;
                   echo "<input class='i_".$inputName."' id='".$inputName."' name='".$inputName."' type='file' ".$paramsOn."  >";  
                   echo '</label>'.NL;
				   echo '<br />';
				   echo "<div id='div_".$inputName."' name='div_".$inputName."' class='div_showPreviewImage' >".NL;
				   echo "<img src=\"\" id='image_".$inputName."' name='image_".$inputName."' alt='' class='img_showPreviewImage' >".NL;
		           echo "</div>".NL;

                   break;
                }
                default:{
                echo '<input class="i_'.$inputName.'" id="'.$inputName.'" type="'.$parametro['type'].'" >'; 
                }
                
            }
         
			
            if(!$error){$this->inputsOfArray[]=$inputName;}     
        }  
            
        foreach ($nombreBotones as $elementos){ 
            echo '<input class="b_'.$formName.'" type="submit" value="'.$elementos.'">';  
            echo "<br />".NL; 
            }  

            
        echo '</form>'.NL;        
        echo '</div>'.NL;                    
    }
    //********************************************************
    //*****funciones de metodos de la clase*******************
     function stringParserInputs($cadena) {
        $inputStr=Array();
        $inputsString=Array();
        $posDatos=Array();
        $inputsArray=Array();
        $inputsString=explode(";",$cadena);
     
        foreach($inputsString as $i => $auxStr){
            $inputStr[$i]=explode(":",$auxStr);            
            }
        foreach($inputStr as $i => $auxStr){
            $posDatos=0; 
            if (substr($auxStr[0],0,2)=='t='){
				
                $inputsArray[$i]['type']=substr($auxStr[0],2,strlen($auxStr[0]));
				$paramType=explode(",",$inputsArray[$i]['type']);
				if (count($paramType)>1){
					if($paramType[0]=='textfield'){
					   $inputsArray[$i]['type']='textfield';
                       $inputsArray[$i]['t_cols']=substr($paramType[1],2);    
                       $inputsArray[$i]['t_rows']=substr($paramType[2],2);						
					}
				}else{
					if($inputsArray[$i]['type']=='fimg'){
						$this->isFileImg=1;   
					}
					
                }
                $posDatos++;
            }
            $inputsArray[$i]['name']=$auxStr[$posDatos]; 
            if(isset($auxStr[$posDatos+1])){
                $inputsArray[$i]['title']=$auxStr[$posDatos+1]; 
            }else{
                $inputsArray[$i]['title']=$auxStr[$posDatos]; 
            }
        }
        return $inputsArray;  
     }
     function returnStringNamesInputs($vector){
         $aux='';
         foreach ($vector as $inputDatos){
            $aux.=$inputDatos['name'].';'; 
         }
         return substr($aux,0,strlen($aux)-1);
     }
   
}   


?>

<?php
$varImage=$_GET['url'];

$varImage = 'file:///'.str_replace("\\\\", "\\", $varImage);
//echo $varImage.'<br>';
echo '<div style="background-image:url(d:\www\lp_logo_gde.jpg);">';
echo '<br>';
echo '<br>';
echo '</div>';
